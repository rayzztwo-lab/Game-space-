package com.gameturbo.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.util.Calendar
import kotlin.math.abs

/**
 * Floating window: garis tipis di ujung layar (kiri/kanan). Ketuk atau geser ke dalam
 * untuk membuka Smart Panel. Garis hanya muncul di atas game (kalau izin deteksi game aktif).
 */
class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { Games.prefs(this) }

    // jendela
    private var handle: FrameLayout? = null
    private var line: View? = null
    private lateinit var lpHandle: WindowManager.LayoutParams
    private var panel: View? = null
    private var lpPanel: WindowManager.LayoutParams? = null

    // isi panel
    private var tvInfo: TextView? = null
    private var tvFps: TextView? = null
    private var arcRam: ArcView? = null
    private var arcTemp: ArcView? = null
    private var arcFps: ArcView? = null
    private var modeViews: List<TextView> = emptyList()
    private var btnDnd: View? = null
    private var btnOn: View? = null
    private var eyeView: View? = null
    private var eyeOn = false
    private var curTab = 0

    // status
    private var gamePkg: String? = null
    private var gameSet: Set<String> = emptySet()
    private var gameSetAt = 0L
    private var rightSide = true
    private var mode = "bal"
    private var keepOn = false
    private var dndOn = false
    private var prevFilter = -1
    private var tickMs = 1000L

    // FPS layar
    private var frames = 0
    private var fps = 0
    private var maxFps = 60
    private var lastMs = 0L
    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            val now = frameTimeNanos / 1_000_000L
            if (lastMs == 0L) lastMs = now
            frames++
            val dt = now - lastMs
            if (dt >= 1000L) {
                fps = (frames * 1000L / dt).toInt()
                if (fps > maxFps && fps <= 165) maxFps = fps
                frames = 0
                lastMs = now
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            detectForeground()
            if (panel != null) refreshPanel()
            handler.postDelayed(this, tickMs)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        rightSide = prefs.getString("side", "right") == "right"
        mode = prefs.getString("mode", "bal") ?: "bal"
        tickMs = if (mode == "save") 3000L else 1000L
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        intent?.getStringExtra(EXTRA_GAME)?.let { gamePkg = it }
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (handle == null) {
            buildHandle()
            handler.post(tick)
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacks(tick)
        Choreographer.getInstance().removeFrameCallback(frameCb)
        removePanel()
        setEye(false)
        handle?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        handle = null
        if (dndOn) setDnd(false)
        super.onDestroy()
    }

    // ---------- util ----------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun screenH(): Int {
        if (Build.VERSION.SDK_INT >= 30) return wm.currentWindowMetrics.bounds.height()
        val m = android.util.DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(m)
        return m.heightPixels
    }

    @Suppress("DEPRECATION")
    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

    private fun baseFlags(): Int {
        var f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (keepOn) f = f or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        return f
    }

    private fun sideGravity(): Int = Gravity.TOP or (if (rightSide) Gravity.END else Gravity.START)

    private fun toast(s: String) = Toast.makeText(applicationContext, s, Toast.LENGTH_SHORT).show()

    private fun openActivity(i: Intent) {
        try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: Exception) {
            toast("Tidak bisa dibuka dari sini")
        }
    }

    // ---------- notifikasi ----------

    private fun startAsForeground() {
        val channelId = "turbo"
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(channelId, "Game Turbo", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
        val stop = PendingIntent.getService(
            this, 0, Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n: Notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Game Turbo aktif")
            .setContentText("Garis panel ada di tepi layar saat main game")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(0, "Matikan", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    // ---------- garis di tepi layar ----------

    private fun lineParams(): FrameLayout.LayoutParams = FrameLayout.LayoutParams(
        dp(5), dp(84), Gravity.CENTER_VERTICAL or (if (rightSide) Gravity.END else Gravity.START)
    )

    private fun buildHandle() {
        val box = FrameLayout(this)
        val l = View(this)
        l.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.parseColor("#FFC247"), Color.parseColor("#FF7A00"))
        ).apply { cornerRadius = dp(3).toFloat() }
        l.alpha = 0.85f
        box.addView(l, lineParams())
        line = l

        lpHandle = WindowManager.LayoutParams(
            dp(24), dp(96), overlayType(), baseFlags(), PixelFormat.TRANSLUCENT
        ).apply {
            gravity = sideGravity()
            x = 0
            y = prefs.getInt("hy", dp(120))
        }

        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var downX = 0f
        var downY = 0f
        var startY = 0
        var dragging = false
        var opened = false
        box.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startY = lpHandle.y
                    dragging = false; opened = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    val inward = if (rightSide) -dx else dx
                    if (!opened && !dragging && inward > dp(16) && abs(dx) > abs(dy)) {
                        opened = true
                        expand()
                    } else if (!opened && (dragging || (abs(dy) > slop && abs(dy) > abs(dx)))) {
                        dragging = true
                        lpHandle.y = (startY + dy).toInt().coerceIn(0, (screenH() - dp(96)).coerceAtLeast(0))
                        try { wm.updateViewLayout(box, lpHandle) } catch (_: Exception) {}
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (opened) {
                        // sudah dibuka lewat geseran
                    } else if (dragging) {
                        prefs.edit().putInt("hy", lpHandle.y).apply()
                    } else {
                        expand()
                    }
                }
            }
            true
        }
        handle = box
        wm.addView(box, lpHandle)
    }

    private fun applySide() {
        prefs.edit().putString("side", if (rightSide) "right" else "left").apply()
        val h = handle ?: return
        lpHandle.gravity = sideGravity()
        line?.layoutParams = lineParams()
        try { wm.updateViewLayout(h, lpHandle) } catch (_: Exception) {}
    }

    private fun applyKeepOn() {
        try {
            handle?.let { lpHandle.flags = baseFlags(); wm.updateViewLayout(it, lpHandle) }
            panel?.let { p -> lpPanel?.let { it.flags = panelFlags(); wm.updateViewLayout(p, it) } }
        } catch (_: Exception) {}
    }

    // ---------- deteksi game di depan ----------

    private fun hasUsage(): Boolean {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager
        @Suppress("DEPRECATION")
        val m = ops.checkOpNoThrow(android.app.AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName)
        return m == android.app.AppOpsManager.MODE_ALLOWED
    }

    @Suppress("DEPRECATION")
    private fun foregroundPkg(): String? {
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val ev = usm.queryEvents(now - 15000L, now)
        val e = UsageEvents.Event()
        var last: String? = null
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) last = e.packageName
        }
        return last
    }

    private fun detectForeground() {
        val h = handle ?: return
        if (!prefs.getBoolean("auto", true) || !hasUsage()) {
            if (h.visibility != View.VISIBLE) h.visibility = View.VISIBLE
            return
        }
        val fg = foregroundPkg() ?: return
        val nowMs = System.currentTimeMillis()
        if (nowMs - gameSetAt > 30000L) {
            gameSet = Games.gamePackages(this); gameSetAt = nowMs
        }
        val isGame = fg in gameSet
        if (isGame) gamePkg = fg
        if (isGame) {
            if (h.visibility != View.VISIBLE) h.visibility = View.VISIBLE
        } else {
            if (panel != null) collapse()
            if (h.visibility != View.GONE) h.visibility = View.GONE
        }
    }

    // ---------- panel ----------

    private fun panelFlags(): Int = baseFlags() or
        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
        WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH

    private fun txt(s: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = s; textSize = size; setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun round(color: Int, r: Int, strokeColor: Int = 0, strokeW: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color); cornerRadius = dp(r).toFloat()
            if (strokeW > 0) setStroke(strokeW, strokeColor)
        }

    private fun setActive(v: View?, on: Boolean) {
        v?.background = if (on)
            GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFFFF8A00.toInt(), 0xFFFFC247.toInt())).apply { cornerRadius = dp(3).toFloat() }
        else round(0xFFEDEFF3.toInt(), 3)
    }

    private fun rowLp(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) }

    private fun newRow(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        background = round(0xFF222833.toInt(), 6)
        setPadding(dp(12), dp(10), dp(12), dp(10))
    }

    /** Baris dengan saklar (putih = mati, oranye = nyala) seperti panel Game Space. */
    private fun switchRow(title: String, on: Boolean, onClick: () -> Unit): Pair<LinearLayout, View> {
        val row = newRow().apply { setOnClickListener { onClick() } }
        row.addView(txt(title, 12.5f, Color.WHITE), LinearLayout.LayoutParams(0, -2, 1f))
        val sw = View(this); setActive(sw, on)
        row.addView(sw, LinearLayout.LayoutParams(dp(34), dp(15)))
        return row to sw
    }

    private fun actionRow(title: String, onClick: () -> Unit): LinearLayout {
        val row = newRow().apply { setOnClickListener { onClick() } }
        row.addView(txt(title, 12.5f, Color.WHITE), LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(txt("›", 18f, Color.parseColor("#9AA3B8")))
        return row
    }

    private fun seekRow(icon: String, max: Int, progress: Int, onChange: (Int) -> Unit): LinearLayout {
        val row = newRow()
        row.addView(txt(icon, 15f, Color.WHITE))
        val sb = SeekBar(this).apply {
            this.max = max; this.progress = progress
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { if (fromUser) onChange(p) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        row.addView(sb, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(6) })
        return row
    }

    private fun page(vararg views: View): ScrollView {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(4), dp(10), dp(10)) }
        views.forEach { col.addView(it, if (it is LinearLayout && it.background != null) rowLp() else LinearLayout.LayoutParams(-1, -2)) }
        return ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(col) }
    }

    private fun setEye(on: Boolean) {
        eyeOn = on
        if (on && eyeView == null) {
            val v = View(this).apply { setBackgroundColor(0x33FF8A00) }
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            try { wm.addView(v, lp); eyeView = v } catch (_: Exception) {}
        } else if (!on) {
            eyeView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
            eyeView = null
        }
    }

    private fun buildBasic(): View {
        val gauges = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        fun arc(label: String): ArcView = ArcView(this).also {
            it.label = label
            val lp = LinearLayout.LayoutParams(dp(64), dp(64)); lp.setMargins(dp(5), dp(4), dp(5), dp(4))
            gauges.addView(it, lp)
        }
        arcRam = arc("RAM"); arcTemp = arc("SUHU"); arcFps = arc("FPS")

        val seg = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = round(0xFF222833.toInt(), 6)
            setPadding(dp(3), dp(3), dp(3), dp(3))
        }
        val names = listOf("save" to "Hemat Daya", "bal" to "Seimbang", "perf" to "Performa")
        modeViews = names.map { (key, label) ->
            txt(label, 11f, Color.parseColor("#9AA3B8")).apply {
                gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(8))
                setOnClickListener { setMode(key, true) }
            }.also { seg.addView(it, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)) }
        }
        updateModeUi()
        val note = txt("FPS = kecepatan gambar layar, bukan FPS di dalam game.", 9.5f, Color.parseColor("#7F889D")).apply { setPadding(0, dp(4), 0, 0) }
        return page(gauges, seg, note)
    }

    private fun buildQuick(): View {
        val eyeR = switchRow("Perawatan Mata", eyeOn) { }.first
        val eyeSw = eyeR.getChildAt(1)
        eyeR.setOnClickListener { setEye(!eyeOn); setActive(eyeSw, eyeOn); toast(if (eyeOn) "Filter hangat aktif" else "Filter hangat mati") }
        val (onR, onSw) = switchRow("Layar Tetap Menyala", keepOn) { toggleKeepOn() }
        btnOn = onSw
        val am = getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
        val bright = seekRow("☀", 255, try { Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) } catch (_: Exception) { 128 }) { p ->
            if (!Settings.System.canWrite(this)) { toast("Izinkan \"Ubah pengaturan sistem\" dulu di app Game Turbo"); return@seekRow }
            try {
                Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, p.coerceAtLeast(5))
            } catch (_: Exception) {}
        }
        val vol = seekRow("🔊", am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC), am.getStreamVolume(android.media.AudioManager.STREAM_MUSIC)) { p ->
            try { am.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, p, 0) } catch (_: Exception) {}
        }
        return page(
            eyeR, onR,
            actionRow("Bersihkan Memori") { doClean() },
            actionRow("Wi-Fi / Internet") { openWifi() },
            bright, vol
        )
    }

    private fun buildAnti(): View {
        val (dR, dSw) = switchRow("Jangan Ganggu", dndOn) { toggleDnd() }
        btnDnd = dSw
        val note = txt("Jangan Ganggu menahan notifikasi dan panggilan selain prioritas selama main. Perlu izin akses Jangan Ganggu.", 10f, Color.parseColor("#7F889D")).apply { setPadding(0, dp(4), 0, 0) }
        return page(dR, note)
    }

    private fun buildExtra(): View = page(
        actionRow("Pindah sisi (kiri / kanan)") { collapse(); rightSide = !rightSide; applySide(); expand() },
        actionRow("Buka Lobby") { collapse(); openActivity(Intent(this, MainActivity::class.java)) },
        actionRow("Matikan Game Turbo") { stopSelf() }
    )

    private fun expand() {
        if (panel != null) return
        val white = Color.WHITE
        val grey = Color.parseColor("#9AA3B8")

        val body = FrameLayout(this)
        val builders = listOf<() -> View>({ buildBasic() }, { buildQuick() }, { buildAnti() }, { buildExtra() })
        val tabs = listOf("🎮" to "Fitur\nDasar", "⚡" to "Akses\nCepat", "🔕" to "Anti\nGangguan", "✨" to "Tambahan")
        val tabViews = ArrayList<TextView>()
        fun showTab(i: Int) {
            curTab = i
            modeViews = emptyList(); btnDnd = null; btnOn = null; arcRam = null; arcTemp = null; arcFps = null
            body.removeAllViews(); body.addView(builders[i]())
            tabViews.forEachIndexed { k, t ->
                t.setTextColor(if (k == i) white else grey)
                t.background = if (k == i) round(0xFF2B3342.toInt(), 6) else null
            }
            refreshPanel()
        }

        // rel kiri
        val rail = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF0F131B.toInt())
            setPadding(dp(4), dp(6), dp(4), dp(6))
        }
        tabs.forEachIndexed { i, (ic, lb) ->
            val t = txt("$ic\n$lb", 9.5f, grey).apply {
                gravity = Gravity.CENTER; setPadding(0, dp(6), 0, dp(6))
                setOnClickListener { showTab(i) }
            }
            tabViews.add(t)
            rail.addView(t, LinearLayout.LayoutParams(-1, 0, 1f).apply { bottomMargin = dp(4) })
        }

        // header
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(8), dp(8), dp(4)) }
        head.addView(txt("GAME TURBO", 11f, Color.parseColor("#FF5B6A"), true).apply { setTypeface(typeface, Typeface.BOLD_ITALIC) })
        val infoTv = txt("--", 10.5f, Color.parseColor("#C8D0E4")).apply { gravity = Gravity.END; setPadding(0, 0, dp(8), 0) }
        tvInfo = infoTv
        head.addView(infoTv, LinearLayout.LayoutParams(0, -2, 1f))
        val fpsTv = txt("FPS --", 11f, Color.parseColor("#FFC247"), true)
        tvFps = fpsTv
        head.addView(fpsTv)
        head.addView(txt("✕", 15f, white).apply { setPadding(dp(12), dp(4), dp(6), dp(4)); setOnClickListener { collapse() } })

        val main = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        main.addView(head)
        main.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))

        val rootRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = round(0xFF181C25.toInt(), 14, 0x33FFFFFF, 1)
            clipToOutline = true
            setOnTouchListener { _, e -> if (e.action == MotionEvent.ACTION_OUTSIDE) { collapse(); true } else false }
        }
        rootRow.addView(rail, LinearLayout.LayoutParams(dp(62), -1))
        rootRow.addView(main, LinearLayout.LayoutParams(0, -1, 1f))

        val lp = WindowManager.LayoutParams(
            dp(330), (screenH() - dp(16)).coerceAtLeast(dp(160)),
            overlayType(), panelFlags(), PixelFormat.TRANSLUCENT
        ).apply { gravity = sideGravity(); x = dp(8); y = dp(8) }
        lpPanel = lp
        panel = rootRow
        wm.addView(rootRow, lp)
        handle?.visibility = View.INVISIBLE
        lastMs = 0L; frames = 0
        Choreographer.getInstance().postFrameCallback(frameCb)
        showTab(curTab)
    }

    private fun removePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null; lpPanel = null
        Choreographer.getInstance().removeFrameCallback(frameCb)
        tvInfo = null; tvFps = null; arcRam = null; arcTemp = null; arcFps = null
        btnDnd = null; btnOn = null; modeViews = emptyList()
    }

    private fun collapse() {
        removePanel()
        handle?.let { if (it.visibility == View.INVISIBLE) it.visibility = View.VISIBLE }
    }

    private fun refreshPanel() {
        val ram = Booster.ramPercent(this)
        val temp = Booster.batteryTempC(this)
        val bat = Booster.batteryPercent(this)
        arcRam?.apply { frac = ram / 100f; valueText = "$ram%" }
        arcTemp?.apply {
            if (temp != null) { frac = ((temp - 20f) / 30f).coerceIn(0f, 1f); valueText = "%.0f°".format(temp) }
            else { frac = 0f; valueText = "--" }
        }
        arcFps?.apply {
            frac = if (fps > 0) fps / maxFps.coerceAtLeast(60).toFloat() else 0f
            valueText = if (fps > 0) "$fps" else "--"
        }
        tvFps?.text = if (fps > 0) "FPS $fps" else "FPS --"
        val c = Calendar.getInstance()
        val clock = "%02d:%02d".format(c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE))
        tvInfo?.text = "$clock   🔋 ${if (bat >= 0) "$bat%" else "--"}"
    }

    // ---------- aksi ----------

    private fun updateModeUi() {
        val keys = listOf("save", "bal", "perf")
        modeViews.forEachIndexed { i, v ->
            val on = keys[i] == mode
            v.setTextColor(if (on) Color.parseColor("#FFC247") else Color.parseColor("#9AA3B8"))
            v.background = if (on) round(0xFF2A1F0C.toInt(), 8, Color.parseColor("#FFB23E"), dp(1)) else null
        }
    }

    private fun setMode(m: String, byUser: Boolean) {
        mode = m
        prefs.edit().putString("mode", m).apply()
        tickMs = if (m == "save") 3000L else 1000L
        updateModeUi()
        if (!byUser) return
        when (m) {
            "perf" -> {
                keepOn = true; applyKeepOn(); setActive(btnOn, true)
                doClean()
                if (nm().isNotificationPolicyAccessGranted) { setDnd(true); setActive(btnDnd, true) }
                toast("Mode Performa: layar tetap menyala, memori dibersihkan")
            }
            "save" -> { toast("Mode Hemat Daya: pembaruan panel diperlambat") }
            else -> toast("Mode Seimbang")
        }
    }

    private fun nm() = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    private fun doClean() {
        val before = Booster.memInfo(this).availMem
        val n = Booster.boost(this, setOfNotNull(gamePkg))
        toast("Menutup $n app di background...")
        handler.postDelayed({
            val freed = (Booster.memInfo(this).availMem - before) / 1048576L
            toast(if (freed > 0) "Selesai, RAM kosong naik sekitar $freed MB" else "Selesai, RAM kamu sudah lega")
        }, 1300L)
    }

    private fun openWifi() {
        collapse()
        val action = if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY else Settings.ACTION_WIFI_SETTINGS
        openActivity(Intent(action))
    }

    private fun setDnd(on: Boolean) {
        val n = nm()
        if (!n.isNotificationPolicyAccessGranted) return
        if (on) {
            if (prevFilter == -1) prevFilter = n.currentInterruptionFilter
            n.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
        } else if (prevFilter >= 1) {
            n.setInterruptionFilter(prevFilter); prevFilter = -1
        }
        dndOn = on
    }

    private fun toggleDnd() {
        if (!nm().isNotificationPolicyAccessGranted) {
            toast("Izinkan akses Jangan Ganggu untuk Game Turbo dulu")
            collapse()
            openActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            return
        }
        setDnd(!dndOn)
        setActive(btnDnd, dndOn)
        toast(if (dndOn) "Jangan Ganggu aktif" else "Jangan Ganggu mati")
    }

    private fun toggleKeepOn() {
        keepOn = !keepOn
        applyKeepOn()
        setActive(btnOn, keepOn)
        toast(if (keepOn) "Layar tetap menyala" else "Layar boleh mati sendiri")
    }

    companion object {
        const val ACTION_STOP = "com.gameturbo.app.STOP"
        const val EXTRA_GAME = "game"
        private const val NOTIF_ID = 2001

        @Volatile
        var running = false

        fun start(ctx: Context, gamePkg: String?) {
            val i = Intent(ctx, OverlayService::class.java)
            if (gamePkg != null) i.putExtra(EXTRA_GAME, gamePkg)
            ContextCompat.startForegroundService(ctx, i)
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, OverlayService::class.java))
        }
    }
}
