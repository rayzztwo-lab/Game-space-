package com.gameturbo.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.View

/** Gauge melingkar oranye (nilai 0..1) dengan angka dan label di tengah. */
class ArcView(ctx: Context) : View(ctx) {

    var frac = 0f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }
    var valueText = "--"
        set(v) { field = v; invalidate() }
    var label = ""
        set(v) { field = v; invalidate() }

    private val stroke = 8f * resources.displayMetrics.density
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = stroke; color = 0x22FFFFFF
    }
    private val prog = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = stroke; strokeCap = Paint.Cap.ROUND
    }
    private val tv = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#E8F6FF"); typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER
    }
    private val tl = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#9AA3B8"); textAlign = Paint.Align.CENTER
    }
    private val rect = RectF()

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val pad = stroke / 2f + 2f
        rect.set(pad, pad, w - pad, h - pad)
        prog.shader = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), Color.parseColor("#19E0FF"), Color.parseColor("#3D5BFF"), Shader.TileMode.CLAMP)
        tv.textSize = h * 0.24f
        tl.textSize = h * 0.13f
    }

    override fun onDraw(c: Canvas) {
        c.drawArc(rect, 0f, 360f, false, track)
        if (frac > 0.005f) c.drawArc(rect, -90f, 360f * frac, false, prog)
        val cy = height / 2f
        c.drawText(valueText, width / 2f, cy + tv.textSize * 0.1f, tv)
        c.drawText(label, width / 2f, cy + tv.textSize * 0.1f + tl.textSize * 1.5f, tl)
    }
}
